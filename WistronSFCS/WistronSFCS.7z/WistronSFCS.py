#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
################################################################################
#
# WistronSFCS.py -- Main interface for xjtag to Wistron servers.
#
# Any use, reproduction, distribution, and/or transfer of this file is strictly
# prohibited without the express written permission of the current copyright
# owner.
#
# Any licensed derivative work must retain this notice.
#
# Copyright (c) 2017 by NIO USA, Inc. All Rights Reserved.
################################################################################




import ftplib
import logging
#from niofct.exceptions import FCTTestError
import sys
import os
import socket
import zeep
import json
import zeep.cache
from zeep import Client

def print_usage(exit_code=0):
    print(
            "Usage: " + str(__file__) + " <serial_number> | [-r] | [-m] | [-c] | [-n] | <employee_id> <result{pass,fail}>] \"date & time\" | [-f] <\\path\\to\\file> \n\n"
            "Notes: [-h] display help\n"
            "       [-r] runs check_route api\n"
            "       [-m] generate mac file for a given serial number using WistronSFCS API\n"
            "       [-c] run complete\n"
            "       [-f] runs FTP on the file provided to the site 172.30.26.23 \n"
            "       [-t] runs a test of the check route, get mac, and complete api\n"
            "       [-n] returns station name"
            )
    sys.exit(exit_code)

class MacSerialUtil():
    MAC_PLACEHOLDER = bytes([0x31,0x32,0x33,0x34,0x35,0x36])  # ASCII 123456
    def __init__(self, serial_no, mac_address=None,  bin_file_name="c:/xjtag/i210_files/black_i210_template.bin"):
        """
        Sets up the utility class with the user specified serial number [and potentially user specified .csv file name,
        if desired in the future].

        :param serial_no: The serial number to search for assignment to or assign to a MAC address.
        :param csv_file_name: The .csv file containing the Serial Number-MAC address assignments.
        :param bin_file_template: The .bin file to copy when generating a new i210 bin file.
        """
        self.bin_file_template = bin_file_name
        self.serial_no = serial_no
        self.mac_address = mac_address
        
    def generate_i210_bin_file(self, file_path='c:\\xjtag\\i210_files\\'):
        """
        Generates an i210 bin file for the specified serial number and writes the assigned MAC address to the bin file.
        :returns: None
        """
        #if ':' in self.mac_address:
        #    mac_address_str_bytes = self.mac_address.split(':')
        #else:
        mac_address_str_bytes = [self.mac_address[byte:byte + 2] for byte in range(0, len(self.mac_address), 2)]
        mac_address_bytes = bytes([int(x, 16) for x in mac_address_str_bytes])
        bin_file_content = None
        try:
            with open(self.bin_file_template, mode='rb') as bin_file:
                bin_file_content = bin_file.read(250000)
                bin_file.close()
            # Replace all occurrences of the template MAC placeholder with the desired MAC
                new_file_content = bin_file_content.replace(self.MAC_PLACEHOLDER, mac_address_bytes, 1)
            with open(file_path + self.serial_no + "_i210.bin", mode='wb') as bin_file:
                bin_file.write(new_file_content)
                bin_file.close()

        except Exception as e:
            print("Error: " + str(e.args))
            sys.exit(-1)

        print("Generated %s" % file_path + self.serial_no + "_i210.bin")

    def generate_mac_bin_file(self, file_path=''):
        """
        Generates an i210 bin file for the specified serial number and writes the assigned MAC address to the bin file.
        :returns: None
        """
        mac_address_str_bytes = [self.mac_address[byte:byte + 2] for byte in range(0, len(self.mac_address), 2)]
        mac_address_bytes = bytes([int(x, 16) for x in mac_address_str_bytes])
        try:
            with open("c:\\xjtag\\mac.bin", mode='wb') as bin_file:
            # Replace all occurrences of the template MAC placeholder with the desired MAC
                new_file_content = mac_address_bytes
                bin_file.write(new_file_content)
                bin_file.close()

        except Exception as e:
            print("Error: " + str(e.args))
            sys.exit(-1)

        print("Generated c:\\xjtag\\mac.bin")


class WistronSFCS(object):
    """Class to interface to the Wistron SFCS."""

    # SFCS Field Length Limitations
    #  - Serial Number <= 30 bytes
    #  - Line <= 5 bytes
    #  - Stage Code == 2 bytes
    #  - Station Name <= 10 bytes
    #  - Employee ID <= 10 bytes

    def __init__(self, file_name="c:\\xjtag\\config.ini"):
        """Save all configuration variables and initialize logger."""
        try:
            with open( file_name, mode='r') as file:
                file_data = file.read()
                file_list = file_data.split()
                #print(file_list)
                file.close()
        except Exception as e:
            print("Error: " + str(e.args))
            sys.exit(-1)
        self.file_name = file_name
        self.url = file_list[file_list.index('URL') + 1]
        self.stage_code = file_list[file_list.index('STAGE_CODE') + 1]
        self.IDtype = file_list[file_list.index('IDTYPE') + 1]
        self.Sequence = file_list[file_list.index('SEQUENCE') + 1]
        self.line = file_list[file_list.index('LINE') + 1]
        self.station_name = file_list[file_list.index('STATION_NAME') + 1]
        self.logger = logging.getLogger('runner')

    def get_name(self):
    	return self.station_name

    def is_alive(self):
        """Check the health of the Wistron SFCS."""
        try:
            transport = zeep.transports.Transport(timeout=10,
                                                  operation_timeout=5,
                                                  cache=zeep.cache.SqliteCache())
            client = zeep.Client(self.url,
                                 transport=transport)

            # Wistron SFCS API:
            # GetCurrentDBSysdate(StageCode: xsd:string,
            #                     DateTimeFormat: xsd:string)
            # -> GetCurrentDBSysdateResult: xsd:string
            client.service.GetCurrentDBSysdate(self.stage_code)
        except Exception as err:
            print('Could not connect to Wistron SFCS.')
            print(str(err))
            return 1

        return 0

    def get_usnid(self, serial_number):
        """Use Wistron SFCS for MAC"""
        self.logger.info('Retrieving Wistron SFCS MAC')

        try:
            transport = zeep.transports.Transport(timeout=60,
                                                  operation_timeout=30,
                                                  cache=zeep.cache.SqliteCache())
            client = zeep.Client(self.url,transport=transport)

        except Exception as err:
            print('Shit\'s wrong!')
            print(str(err))
            return 1

        for i in range(5):
            try:
                response = client.service.GetUsnID(serial_number, self.stage_code, self.IDtype, self.Sequence)
                return (response)
                break
            except Exception as err:
                self.logger.error('Shit\'s wrong!')
                print(str(err))
            
        return 0
    def check_route(self, serial_number):
        """Check Wistron SFCS for OK/NG to start testing."""
        self.logger.info('Checking Wistron SFCS for OK Status...')

        try:
            transport = zeep.transports.Transport(timeout=60,
                                                  operation_timeout=30,
                                                  cache=zeep.cache.SqliteCache())
            client = zeep.Client(self.url,
                                 transport=transport)
        except Exception as err:
            self.logger.error('Could not connect to SFCS.')
            #raise FCTTestError(str(err))

        for i in range(5):
            try:
                # Wistron SFCS API:
                # CheckRoute(UnitSerialNumber: xsd:string,
                #            StageCode: xsd:string)
                # -> CheckRouteResult: xsd:string
                response = client.service.CheckRoute(serial_number, self.stage_code)
                break
            except Exception as err:
                self.logger.error('Try {}/5 - SFCS Error: {}'.format(i + 1, str(err)))
                response = "BAD"
            #else:
                #raise FCTTestError('Did not receive OK message from Wistron SFCS')

        if response != 'OK':
            print('THERE WAS AN ERROR! CHECKROUTE FAILED')
            self.logger.error('Wistron SFCS Response: {}'.format(response))
            #raise FCTTestError('Did not receive OK message from Wistron SFCS')
            return 1
        else:
            #print('Ok!\n')
            #print(response)
            self.logger.info('Received OK status from Wistron SFCS.')
            return 0
    def complete(self,
                 serial_number,
                 employee_id,
                 result,
                 transaction_data):
        """Send a status update to Wistron SFCS."""
        self.logger.info('Updating status with Wistron SFCS...')

        try:
            transport = zeep.transports.Transport(timeout=60,
                                                  operation_timeout=30,
                                                  cache=zeep.cache.SqliteCache())
            client = zeep.Client(self.url,
                                 transport=transport)
        except Exception as err:
            self.logger.error('Could not connect to SFCS.')
            raise FCTTestError(str(err))

        # We should only report pass or failing.
        if result.upper() == 'PASS':
            result = True
        elif result.upper() == 'FAIL':
             result = False
        else:
            self.logger.info('Not updating SFCS due to status={}. Returning...'.format(result))
            return

        #station_name = test_type + socket.gethostname()[-3:]

        for i in range(5):
            try:
                # Wistron SFCS API:
                # API Complete(UnitSerialNumber: xsd:string,
                #              Line: xsd:string,
                #              StageCode: xsd:string,
                #              StationName: xsd:string,
                #              EmployeeID: xsd:string,
                #              Pass: xsd:boolean,
                #              TrnDatas: ns0:ArrayOfString)`
                # -> CompleteResult: xsd:string
                string_array_type = client.get_type('ns0:ArrayOfString')
                transaction_array = string_array_type(transaction_data)
                
                response = client.service.Complete(serial_number,
                                                   self.line,
                                                   self.stage_code,
                                                   self.station_name,
                                                   employee_id,
                                                   result,
                                                   TrnDatas=transaction_array)
                break
            except Exception as err:
                self.logger.error('Try {}/5 - SFCS Error: {}'.format(i, str(err)))
            else:
                raise

        if response != 'OK':
            self.logger.error('Did not receive OK message from Wistron SFCS')
            self.logger.error(response)
        else:
            self.logger.info('Received OK status from Wistron SFCS.')

class WistronFTP(object):
    """Class to interface to the Wistron FTP."""

    def __init__(self, host, username, password, path):
        """Save all configuration variables and initialize logger."""
        self.host = host
        #self.port = port
        self.username = username
        self.password = password
        self.path = path
        self.logger = logging.getLogger('runner')

    def is_alive(self):
        """Check the health of the Wistron FTP."""
        try:
            with ftplib.FTP(host=self.host,
                            user=self.username,
                            passwd=self.password,
                            timeout=5):

                pass
        except Exception as e:
            print("Could not connect to Wistron FTP.\n")
            print("error: \n")
            print(e)
            return False

        return True

    def transfer_file(self, log_path):
        """Send a file to Wistron FTP."""
        log_filename = os.path.basename(log_path)
        print("log_filename: " , log_filename, "\n")
        #log_filename = log_path
        #print(log_path,"\n")
        stor_cmd = 'STOR {}{}'.format(self.path, log_filename)
        
        print("path: ", self.path, "\n")

        print("stor_cmd: ", stor_cmd, "\n")
        # # self.logger.info('Uploading log {} to Wistron FTP...'.format(log_filename))

        for i in range(5):
            try:
                with ftplib.FTP(host=self.host,
                                user=self.username,
                                passwd=self.password,
                                timeout=30) as ftp:
                    ftp.storbinary(stor_cmd, open(log_path, 'rb'))
                break
            except OSError:
                self.logger.error('Could not find Wistron FTP via host {}'.format(self.host))
            except socket.timeout:
                self.logger.error('Could not connect to Wistron FTP')
            except ftplib.all_errors as e:
                self.logger.error('Could not transfer log file to Wistron FTP service.')
                
                print(e)
            except Exception as e:
                self.logger.error('Encountered unexpected exception while trying to transfer log to Wistron FTP.')
                print(e)
            else:
                raise




if __name__ == '__main__':
    argv = sys.argv
    argc = len(argv)
    print("WistronSFCS Version 4.1 03/07/18")    
    if argc> 1:
        if '-h' in argv or '--help' in argv:
            print_usage()
            sys.exit(0)
        if '-m' in argv or '--mac' in argv:
            print('-m\n')
            serve = WistronSFCS()
            result = serve.is_alive()
            if (result==1):
            	print("is not alive...")
            	sys.exit(1)

            print('is alive!')
            serial_number = argv[1]
            result = serve.check_route(serial_number)
            print(result)
            if (result==0):
                macaddr = serve.get_usnid(serial_number)
                print("Retrieved MAC! -- got ",macaddr,"\n")
                print("generating file...")
                util = MacSerialUtil(serial_number,macaddr)
                gen_i210 = util.generate_i210_bin_file()
                gen_mac = util.generate_mac_bin_file()
                sys.exit(0)
            else:
            	print("check route failed...")
            	sys.exit(1)

        if '-r' in argv or '--route' in argv:
            print('-r\n')
            serve = WistronSFCS()
            serve.is_alive()
            result = serve.is_alive()
            if (result==1):
            	print("is not alive...")
            	sys.exit(1)
            print('is alive!')
            serial_number = argv[1]
            result = serve.check_route(serial_number)
            if (result==1):
            	print("check route failed!...")
            	sys.exit(1)
            sys.exit(0)

        if '-c' in argv or '--complete' in argv:
            '''
            def complete(self,
                 serial_number,
                 test_type,
                 line,
                 employee_id,
                 result,
                 transaction_data):
            '''
            serve = WistronSFCS()
            serve.is_alive()
            serial_number = argv[1]
            employee_id = argv[argv.index('-c') + 1]
            test_result = argv[argv.index('-c') + 2]
            date_time = argv[argv.index('-c') + 3]
            result = serve.complete(serial_number, employee_id, test_result, date_time)
                                    #std

            #python wistronsfcs.py sernohere -c username.xjtagvar, result, "format(d/t)                                                                                             

            #[-c <line> <station_name> <employee_id> <pass{true,fail}>] | [-t]\n\n"

        if '-f' in argv or '-F' in argv or '--ftp' in argv:
            #def __init__(self, host,  username, password, path):
            
            filename = argv[argv.index('-f') + 1]
            site = "172.30.26.23"
            user = "NIO_Log"
            pswrd = "nio"
            path = "\\X_JTAG\\"
            print("site: ", site, "\nuser: ", user,"\npassword: ",pswrd,"\nFTP path: ", path,"\ntransfer file: ",filename,"\n")

            ftp = WistronFTP(site,user,pswrd,path)
            print("Test that the FTP server is alive.")
            result = ftp.is_alive()
            print(result,"\n")
            if (result):
                print("ftp attempt \n")
                result = ftp.transfer_file(filename)
                print(result,"\n")  
            else:
                print("the server is not alive")  

        if '-t' in argv or '--test' in argv:
             serve = WistronSFCS()
             serve.is_alive()
             serial_number = 'NLPWKJ1048A0CC'
             result = serve.check_route(serial_number)
             print(result)
             if (result):
                 macaddr = serve.get_usnid(serial_number)
                 print(str(macaddr))
                 util = MacSerialUtil(serial_number,"8c147d0f000f")
                 gen_i210 = util.generate_i210_bin_file()
                 gen_mac = util.generate_mac_bin_file()
        if '-n' in argv or '--name' in argv:
        	serve = WistronSFCS()
        	name = serve.get_name()
        	print(name,"\n")


    else:
        print_usage(1)
        
        

#    client = Client('http://172.30.50.186/Tester.WebService/WebService.asmx?wsdl')
 #    node = client.create_message(client.service, 'myOperation', user='hi')


#establish server
#check route(serial)
#if OK
#mac = get_usnid(serial)
#if mac = (8c147d...)
#generate i210